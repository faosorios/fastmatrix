/* ID: specmat.h, last updated 2020-08-01, F.Osorio */

#ifndef FASTMAT_SPECMAT_H
#define FASTMAT_SPECMAT_H

#include "base.h"

extern void dupl_cols(int *, int *);

#endif /* FASTMAT_SPECMAT_H */
